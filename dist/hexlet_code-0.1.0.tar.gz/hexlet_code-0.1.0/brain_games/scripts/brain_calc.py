#!/usr/bin/env python3
# script: calc
from brain_games.game import engine_games


def main():
    print('What is the result of the expression?')
    engine_games('calc')


if __name__ == '__main__':
    main()
